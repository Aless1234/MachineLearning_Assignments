import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
import seaborn as sns

#read data
alg_data = pd.read_csv(r'C:\Users\alessia\Documents\Università\IML_Project\Algerian_forest_fires_dataset_UPDATE.csv', sep=',')
alg_data.dropna(inplace=True)
alg_data.drop(labels=123, axis=0, inplace=True)
alg_data['region'] = np.where(alg_data.index < 123, 1, 2)
alg_data.columns = alg_data.columns.str.replace(' ', '')
alg_data['Classes'] = alg_data['Classes'].apply(lambda x: x.replace(' ', ''))
alg_data = alg_data.rename(columns={'Temperature': 'Temp'})
print(alg_data)
print(alg_data.columns)

#kde plots of attributes
columns_1 = alg_data.columns[3:-2]
for column in columns_1:
    alg_data[column] = pd.to_numeric(alg_data[column], downcast="float")
    sns.kdeplot(alg_data[column], color='blue', shade=True)
    plt.show()

#correlation matrix of df
dataplot = sns.heatmap(alg_data[columns_1].corr())
plt.show()

columns_2 = alg_data.columns[3:7]
#histogram plots of attributes
for column in columns_2:
    alg_data[column] = pd.to_numeric(alg_data[column], downcast="float")
    plt.hist(alg_data[column], 20, density=1, color='royalblue',alpha=0.9)
    plt.xlabel(column)
    plt.ylabel('Density')
    plt.show()

alg_data_test = (alg_data[columns_2])
#standardize data
alg_data_stand = StandardScaler().fit_transform(alg_data[columns_2])

#apply PCA
pca = PCA(n_components=4)
pca.fit(alg_data_stand)
alg_data_pc = pca.fit_transform(alg_data_stand)

#print relevant paramters
print(pca.components_)
print(pca.explained_variance_ratio_)

#plot explained variance by components
expl_var_cumsum = pca.explained_variance_ratio_.cumsum()
plt.plot([0, 1, 2, 3, 4], np.insert(expl_var_cumsum, 0, 0, axis=0))
plt.plot([0, 1, 2, 3, 4], np.insert(pca.explained_variance_ratio_, 0, 0, axis=0), color='r')
plt.legend(['cumulative', 'individual'])
plt.title('explained variance as function of principle components')
plt.xlabel('principal components')
plt.ylabel('explained variance')
plt.ylim(0, 1)
plt.xlim(1,4)
plt.xticks([0, 1, 2, 3, 4])
plt.show()

#plot data in space of first two principal components
plt.scatter(alg_data_pc[:, 0], alg_data_pc[:, 1])
plt.title('data in space of first two principal components')
plt.xlabel('principal component 1')
plt.ylabel('principal component 2')
plt.show()


#plot linear combination of pca components
components = pca.components_
swapped_components = np.swapaxes(components,0,1)
#swapped_components = np.concatenate((swapped_components, [np.ones(10)]))
print(swapped_components)

# set width of bars
barWidth = 0.15

# Set position of bar on X axis
r1 = np.arange(len(swapped_components[0]))
r2 = [x + barWidth for x in r1]
r3 = [x + barWidth for x in r2]
r4 = [x + barWidth for x in r3]


# Make the plot
plt.bar(r1, swapped_components[0], color='red', width=barWidth, edgecolor='white', label=columns_2[0])
plt.bar(r2, swapped_components[1], color='green', width=barWidth, edgecolor='white', label=columns_2[1])
plt.bar(r3, swapped_components[2], color='blue', width=barWidth, edgecolor='white', label=columns_2[2])
plt.bar(r4, swapped_components[3], color='black', width=barWidth, edgecolor='white', label=columns_2[3])


# Add xticks on the middle of the group bar
plt.xlabel('group', fontweight='bold')
plt.xticks([r + 5*barWidth for r in range(len(swapped_components[0]))], ['PC1', 'PC2', 'PC3', 'PC4'])

# Create legend & Show graphic
plt.legend()
plt.show()







