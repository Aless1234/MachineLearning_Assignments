# ------------------------------------------------------------------------------------------------------------------
# Implementation of 2-fold
# ------------------------------------------------------------------------------------------------------------------

import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
import scipy

#read data
use_region = False
help = 1
alg_data = pd.read_csv(r"C:\Users\alessia\Documents\Università\IML_Project\Algerian_forest_fires_dataset_UPDATE.csv", sep=',')
alg_data.dropna(inplace=True)
alg_data.drop(labels=123, axis=0, inplace=True)
alg_data.columns = alg_data.columns.str.replace(' ', '')
alg_data['Classes'] = alg_data['Classes'].apply(lambda x: x.replace(' ', ''))
alg_data = alg_data.rename(columns={'Temperature': 'Temp'})
if use_region:
    alg_data['region'] = 0
    alg_data.loc[0:123, 'region'] = 1
    help = 2
print(alg_data)
print(alg_data.columns)

#kde plots of attributes
columns = alg_data.columns[3:-help]
for column in columns:
    alg_data[column] = pd.to_numeric(alg_data[column], downcast="float")

#randomize order of rows in df
alg_data = alg_data.sample(frac=1, random_state=1).reset_index(drop=True)

if use_region:
    X = alg_data[['Temp', 'RH', 'Ws', 'Rain', 'region']]
else:
    X = alg_data[['Temp', 'RH', 'Ws', 'Rain']]

X_class = StandardScaler().fit_transform(X)
Y_class = alg_data[['Classes']]
Y_class.Classes[Y_class.Classes == 'fire'] = 1
Y_class.Classes[Y_class.Classes == 'notfire'] = 0
Y_class = Y_class.to_numpy()


# ------------------------------------------------------------------------------------------------------------------
# Classification (Logistic Regression and KNN) in 2-fold cross validation
# ------------------------------------------------------------------------------------------------------------------

k1 = 10
k2 = 10

results_table = pd.DataFrame(columns=['i', 'k*', 'E_test_knn', 'lambda*', 'E_test_lr', 'E_test_bl'], index=range(k1))

row_number = np.floor(X_class.shape[0]/10)
gen_error = np.zeros(k1)

test_error_outer_bl = np.zeros((k1))
test_error_outer_lr = np.zeros((k1))
test_error_outer_knn = np.zeros((k1))

r_j_1 = np.zeros((k1))
r_j_2 = np.zeros((k1))
r_j_3 = np.zeros((k1))

# outer loop
for i1 in range(k1):

    print('outer loop: ', i1+1)
    results_table['i'][i1] = i1+1

    # create individual test training split
    indices = list(np.arange(i1*row_number,((i1+1)*row_number)))
    indices = [int(o) for o in indices]

    X_train, X_test = np.delete(X_class, indices, 0), X_class[int(i1*row_number):int((i1+1)*row_number), :]
    Y_train, Y_test = np.delete(Y_class, indices, 0), Y_class[int(i1*row_number):int((i1+1)*row_number), :]

    row_number_inner = np.floor(X_train.shape[0] / k2)

    #define complexity controlling parameters to be looped over

    ks = np.arange(1, 20, 1)
    lambdas = np.insert(np.arange(0.2, 80, 0.2), 0, 0.0001, axis=0)

    test_error_inner_knn = np.zeros((len(ks), k2))
    test_error_inner_lr = np.zeros((len(lambdas), k2))

    # inner loop
    for i2 in range(k2):

        # create individual test training split
        indices = list(np.arange(i2 * row_number_inner, ((i2 + 1) * row_number_inner)))
        indices = [int(o) for o in indices]
        X_train_inner, X_test_inner = np.delete(X_train, indices, 0), X_train[int(i2 * row_number_inner):int((i2 + 1) * row_number_inner), :]
        Y_train_inner, Y_test_inner = np.delete(Y_train, indices, 0), Y_train[int(i2 * row_number_inner):int((i2 + 1) * row_number_inner), :]

        # KNN Classification
        # ---------------------------------------------------------------------------------------------------------------
        count = 0
        for k in ks:

            predictions = np.zeros(Y_test_inner.shape[0])

            for idx in range(X_test_inner.shape[0]):

                # compute distance of reviewed row to all elements in train data
                X_diff = X_train_inner - X_test_inner[idx, :]
                X_diff = np.multiply(X_diff, X_diff)
                X_diff = np.sum(X_diff, axis=1)

                # find 11 smallest distances in X_diff
                k_smallest_idx = np.argsort(X_diff)[:k]
                k_smallest_classes = Y_train[k_smallest_idx]

                # save prediction made
                if (np.mean(k_smallest_classes) > 0.5):
                    predictions[idx] = 1
                elif (np.mean(k_smallest_classes) == 0.5):
                    #if neighbors are tied stick with baseline
                    predictions[idx] = np.round(np.mean(Y_train_inner))
                else:
                    predictions[idx] = 0

            y_diff = Y_test_inner.transpose() - predictions
            number_wrong_predictions = np.sum(np.square(y_diff))

            test_error_inner_knn[count, i2] = number_wrong_predictions / len(predictions)
            count += 1
        # ---------------------------------------------------------------------------------------------------------------


        # logistic regression evaluation
        #---------------------------------------------------------------------------------------------------------------
        count=0
        for param_lambda in lambdas:

            Y_train_inner = Y_train_inner.squeeze().astype('int')

            model = LogisticRegression(penalty='l2', C=1 / param_lambda)
            model.fit(X_train_inner, Y_train_inner)
            y_test_est = model.predict(X_test_inner).T

            test_error_inner_lr[count,i2] = np.sum(y_test_est != Y_test_inner.squeeze().astype('int')) / len(Y_test_inner)
            count += 1
        #---------------------------------------------------------------------------------------------------------------


    gen_error_inner_lr = np.mean(test_error_inner_lr, axis=0)
    gen_error_inner_knn = np.mean(test_error_inner_knn, axis=0)

    # Baseline model outer loop test_error
    #-------------------------------------------------------------------------------------------------------------------
    # train model on all of train data
    y_hat_bl_opt = np.round(np.mean(Y_train))
    y_diff_bl = Y_test - y_hat_bl_opt
    test_error_outer_bl[i1] = np.matmul(y_diff_bl.transpose(), y_diff_bl) / Y_test.shape[0]
    results_table['E_test_bl'][i1] = np.round(float(np.matmul(y_diff_bl.transpose(), y_diff_bl) / Y_test.shape[0]), 3)
    #-------------------------------------------------------------------------------------------------------------------


    # Logistic regression model outer loop test_error
    #-------------------------------------------------------------------------------------------------------------------
    # find optimal lambda from inner loop
    lambda_opt = lambdas[np.where(gen_error_inner_lr == gen_error_inner_lr.min())]
    results_table['lambda*'][i1] = np.round(lambda_opt[0], 3)

    Y_train_copy = Y_train.squeeze().astype('int')

    model = LogisticRegression(penalty='l2', C=1 / lambda_opt[0])
    model.fit(X_train, Y_train_copy)
    y_test_est = model.predict(X_test).T

    y_diff_lr = y_test_est - Y_test.squeeze().T

    test_error_outer_lr[i1] = np.sum(y_test_est != Y_test.squeeze().astype('int')) / len(Y_test)
    results_table['E_test_lr'][i1] = np.round(np.sum(y_test_est != Y_test.squeeze().astype('int')) / len(Y_test), 3)
    #-------------------------------------------------------------------------------------------------------------------


    # KNN model outer loop test_error
    #-------------------------------------------------------------------------------------------------------------------
    # find optimal k from inner loop
    k_opt = ks[np.where(gen_error_inner_knn == gen_error_inner_knn.min())]
    results_table['k*'][i1] = k_opt[0]

    predictions = np.zeros(Y_test.shape[0])

    for idx in range(X_test.shape[0]):

        # compute distance of reviewed row to all elements in train data
        X_diff = X_train - X_test[idx, :]
        X_diff = np.multiply(X_diff, X_diff)
        X_diff = np.sum(X_diff, axis=1)

        # find 11 smallest distances in X_diff
        k_smallest_idx = np.argsort(X_diff)[:k_opt[0]]
        k_smallest_classes = Y_train[k_smallest_idx]

        # save prediction made
        if (np.mean(k_smallest_classes) > 0.5):
            predictions[idx] = 1
        elif (np.mean(k_smallest_classes) == 0.5):
            # if neighbors are tied stick with baseline
            predictions[idx] = np.round(np.mean(Y_train))
        else:
            predictions[idx] = 0

    y_diff = Y_test.transpose() - predictions
    number_wrong_predictions = np.sum(np.square(y_diff))
    test_error_outer_knn[i1] = number_wrong_predictions / len(predictions)
    results_table['E_test_knn'][i1] = np.round(number_wrong_predictions / len(predictions), 3)
    #-------------------------------------------------------------------------------------------------------------------

    #statistical tests comparing
    #-------------------------------------------------------------------------------------------------------------------
    # logistic regression and knn
    r_j_1[i1] = (1/len(y_diff_lr))*np.sum(y_diff.squeeze()**2 - y_diff_lr**2)
    # logistic regression and baseline
    r_j_2[i1] = (1/len(y_diff_lr))*np.sum(y_diff_bl.squeeze()**2 - y_diff_lr**2)
    # knn and baseline
    r_j_3[i1] = (1/len(y_diff_lr))*np.sum(y_diff_bl.squeeze()**2 - y_diff.squeeze()**2)
    #-------------------------------------------------------------------------------------------------------------------


#train logistic regression with somewhat optimal regularization parameter lambda
#-------------------------------------------------------------------------------------------------------------------

Y_copy = Y_class.squeeze().astype('int')

model = LogisticRegression(penalty='l2', C=1 / 1.4)
model.fit(X_class, Y_copy)
result = [model.intercept_, model.coef_]
print(result)

#p value and confidence intervals
#-------------------------------------------------------------------------------------------------------------------
#t distribution
dof = k1 - 1
t_dist = scipy.stats.t(dof)

# rho can be assumed = 0 as our test sets don't overlap
rho = 0
alpha = 0.05

# p-val for logistic regression and knn
r_mean_1 = np.mean(r_j_1)
sigma_1 = (1/(k1-1))*np.sum((r_j_1 - r_mean_1)**2)
t_hat_1 = r_mean_1/(np.sqrt(sigma_1)*np.sqrt(1/k1 + rho/(1-rho)))
p_val_1 = 2*t_dist.cdf(-abs(t_hat_1))
print('p_val_1:', p_val_1)

# 1-alpha confidence interval
lb_1 = scipy.stats.t.ppf(alpha/2, df=dof, loc=r_mean_1, scale=np.sqrt(sigma_1*(1/k1 + 1/(k1-1))))
print('lower bound 1: ', lb_1)
ub_1 = scipy.stats.t.ppf(1 - (alpha/2), df=dof, loc=r_mean_1, scale=np.sqrt(sigma_1*(1/k1 + 1/(k1-1))))
print('upper bound 1: ', ub_1)


# logistic regression and baseline
r_mean_2 = np.mean(r_j_2)
sigma_2 = (1/(k1-1))*np.sum((r_j_2 - r_mean_2)**2)
t_hat_2 = r_mean_2/(np.sqrt(sigma_2)*np.sqrt(1/k1 + rho/(1-rho)))
p_val_2 = 2*t_dist.cdf(-abs(t_hat_2))
print('p_val_2:', p_val_2)

# 1-alpha confidence interval
lb_2 = scipy.stats.t.ppf(alpha/2, df=dof, loc=r_mean_2, scale=np.sqrt(sigma_2*(1/k1 + 1/(k1-1))))
print('lower bound 2: ', lb_2)
ub_2 = scipy.stats.t.ppf(1 - (alpha/2), df=dof, loc=r_mean_2, scale=np.sqrt(sigma_2*(1/k1 + 1/(k1-1))))
print('upper bound 2: ', ub_2)


# knn and baseline
r_mean_3 = np.mean(r_j_3)
sigma_3 = (1/(k1-1))*np.sum((r_j_3 - r_mean_3)**2)
t_hat_3 = r_mean_3/(np.sqrt(sigma_3)*np.sqrt(1/k1 + rho/(1-rho)))
p_val_3 = 2*t_dist.cdf(-abs(t_hat_3))
print('p_val_3:', p_val_3)

# 1-alpha confidence interval
lb_3 = scipy.stats.t.ppf(alpha/2, df=dof, loc=r_mean_3, scale=np.sqrt(sigma_3*(1/k1 + 1/(k1-1))))
print('lower bound 3: ', lb_3)
ub_3 = scipy.stats.t.ppf(1 - (alpha/2), df=dof, loc=r_mean_3, scale=np.sqrt(sigma_3*(1/k1 + 1/(k1-1))))
print('upper bound 3: ', ub_3)
#-------------------------------------------------------------------------------------------------------------------


print(results_table)
print('end')

