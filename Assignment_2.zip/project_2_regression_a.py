import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.preprocessing import StandardScaler
import torch
from toolbox_02450 import train_neural_net

#read data
alg_data = pd.read_csv(r"C:\Users\alessia\Documents\Università\IML_Project\Algerian_forest_fires_dataset_UPDATE.csv", sep=',')
alg_data.dropna(inplace=True)
alg_data.drop(labels=123, axis=0, inplace=True)
alg_data.columns = alg_data.columns.str.replace(' ', '')
alg_data['Classes'] = alg_data['Classes'].apply(lambda x: x.replace(' ', ''))
alg_data = alg_data.rename(columns={'Temperature': 'Temp'})
print(alg_data)
print(alg_data.columns)

#kde plots of attributes
columns = alg_data.columns[3:-1]
for column in columns:
    alg_data[column] = pd.to_numeric(alg_data[column], downcast="float")

# randomize order of rows in df
alg_data = alg_data.sample(frac=1, random_state=1).reset_index(drop=True)

X = alg_data[['Temp', 'RH', 'Ws', 'Rain']]
X_stand = StandardScaler().fit_transform(X)
X_stand = np.append(np.ones((X.shape[0],1)), X_stand, axis=1)

Y = alg_data[['FWI']]
Y_cent = (Y - np.mean(Y)).to_numpy()


#------------------------------------------------------------------------------------------------------------------
#Regression part a
#------------------------------------------------------------------------------------------------------------------

#iterate over different options for lambda and use 10-fold cross-validation to compute respective generalized error
param_lambda = 0.01
row_number = np.floor(X_stand.shape[0]/10)
lambdas = np.arange(0, 1000, 0.2)
gen_error = np.zeros((len(lambdas)))
w_evolve = np.zeros((5, len(lambdas)))
iter = 0


for param_lambda in lambdas:

    test_error = np.zeros((10))

    #10-Fold cross validation™
    for i in range(10):

        #create individual test training split
        indices = list(np.arange(i*row_number,((i+1)*row_number)))
        indices = [int(o) for o in indices]
        X_train, X_test = np.delete(X_stand, indices, 0), X_stand[int(i*row_number):int((i+1)*row_number), :]
        Y_train, Y_test = np.delete(Y_cent, indices, 0), Y_cent[int(i*row_number):int((i+1)*row_number), :]

        #compute param_vector w
        w = np.matmul(np.linalg.inv(np.matmul(X_train.transpose(),X_train) + param_lambda*np.identity(X_train.shape[1])),(np.matmul(X_train.transpose(),Y_train)))

        #make prediction on test_data
        y_hat = np.matmul(X_test, w)
        y_diff = Y_test - y_hat
        test_error[i] = np.matmul(y_diff.transpose(), y_diff)/Y_test.shape[0]


    gen_error[iter] = np.mean(test_error)
    lambdas[iter] = param_lambda
    w_evolve[0,iter] = w[0]
    w_evolve[1,iter] = w[1]
    w_evolve[2,iter] = w[2]
    w_evolve[3,iter] = w[3]
    w_evolve[4,iter] = w[4]
    iter += 1

# find optimal lambda
lambda_opt = lambdas[np.where(gen_error == gen_error.min())]
print(lambda_opt)

w_opt = np.matmul(np.linalg.inv(np.matmul(X_train.transpose(),X_train) + lambda_opt*np.identity(X_train.shape[1])),(np.matmul(X_train.transpose(),Y_train)))
print(w_opt)

plt.plot(lambdas, gen_error)
plt.xlabel('lambda')
plt.ylabel('gen-error estimate')
plt.xlim([0, 40])
plt.ylim([29.99, 30.17])
plt.grid()
plt.show()


#plt.plot(lambdas, w_evolve[0,:], label = "beta_0")
#plt.plot(lambdas, w_evolve[1,:], label = "beta_1")
#plt.plot(lambdas, w_evolve[2,:], label = "beta_2")
#plt.plot(lambdas, w_evolve[3,:], label = "beta_3")
#plt.plot(lambdas, w_evolve[4,:], label = "beta_4")
#plt.xlabel('lambda')
#plt.ylabel('parameter estimates')
#plt.legend()
#plt.xlim([0, 1000])
#plt.ylim([-3, 3])
#plt.grid()
#plt.show()

print('Finished Regression part a')