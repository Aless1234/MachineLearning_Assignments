import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.preprocessing import StandardScaler
import torch
from toolbox_02450 import train_neural_net
import scipy

#read data
alg_data = pd.read_csv(r'C:\Users\alessia\Documents\Università\IML_Project\Algerian_forest_fires_dataset_UPDATE.csv', sep=',')
alg_data.dropna(inplace=True)
alg_data.drop(labels=123, axis=0, inplace=True)
alg_data.columns = alg_data.columns.str.replace(' ', '')
alg_data['Classes'] = alg_data['Classes'].apply(lambda x: x.replace(' ', ''))
alg_data = alg_data.rename(columns={'Temperature': 'Temp'})
print(alg_data)
print(alg_data.columns)

#kde plots of attributes
columns = alg_data.columns[3:-1]
for column in columns:
    alg_data[column] = pd.to_numeric(alg_data[column], downcast="float")

# randomize order of rows in df
alg_data = alg_data.sample(frac=1, random_state=1).reset_index(drop=True)

X = alg_data[['Temp', 'RH', 'Ws', 'Rain']]
X_stand = StandardScaler().fit_transform(X)
X_stand = np.append(np.ones((X.shape[0],1)), X_stand, axis=1)

Y = alg_data[['FWI']]
Y_cent = (Y - np.mean(Y)).to_numpy()

#------------------------------------------------------------------------------------------------------------------
#Regression part b
#------------------------------------------------------------------------------------------------------------------

k1 = 10
k2 = 10

results_table = pd.DataFrame(columns=['i', 'h*', 'E_test_ann', 'lambda*', 'E_test_lr', 'E_test_bl'], index=range(k1))

row_number = np.floor(X_stand.shape[0]/k1)
iter = 0
test_error_outer_bl = np.zeros((k1))
test_error_outer_rg = np.zeros((k1))
test_error_outer_ann = np.zeros((k1))

r_j_1 = np.zeros((k1))
r_j_2 = np.zeros((k1))
r_j_3 = np.zeros((k1))

# outer loop
for i1 in range(k1):

    print('outer loop: ', i1+1)
    results_table['i'][i1] = i1+1

    # create individual test training split
    indices = list(np.arange(i1*row_number,((i1+1)*row_number)))
    indices = [int(o) for o in indices]
    X_train, X_test = np.delete(X_stand, indices, 0), X_stand[int(i1*row_number):int((i1+1)*row_number), :]
    Y_train, Y_test = np.delete(Y_cent, indices, 0), Y_cent[int(i1*row_number):int((i1+1)*row_number), :]

    row_number_inner = np.floor(X_train.shape[0] / k2)
    lambdas = np.arange(0, 40, 0.2)
    hidden_units = np.arange(1, 10, 1)

    # inner loop
    test_error_inner_rg = np.zeros((len(lambdas), k2))
    test_error_inner_ann = np.zeros((len(hidden_units), (k2)))

    # 10-Fold cross validation
    for i2 in range(k2):
        # create individual test training split
        indices = list(np.arange(i2 * row_number_inner, ((i2 + 1) * row_number_inner)))
        indices = [int(o) for o in indices]
        X_train_inner, X_test_inner = np.delete(X_train, indices, 0), X_train[int(i2 * row_number_inner):int((i2 + 1) * row_number_inner), :]
        Y_train_inner, Y_test_inner = np.delete(Y_train, indices, 0), Y_train[int(i2 * row_number_inner):int((i2 + 1) * row_number_inner), :]

        # regression evaluation
        #---------------------------------------------------------------------------------------------------------------
        count=0
        for param_lambda in lambdas:
            w = np.matmul(np.linalg.inv(np.matmul(X_train_inner.transpose(), X_train_inner) + param_lambda * np.identity(X_train_inner.shape[1])),
                (np.matmul(X_train_inner.transpose(), Y_train_inner)))
            y_hat_rg = np.matmul(X_test_inner, w)
            y_diff_rg = Y_test_inner - y_hat_rg
            test_error_inner_rg[count,i2] = np.matmul(y_diff_rg.transpose(), y_diff_rg) / Y_test_inner.shape[0]
            count += 1
        #---------------------------------------------------------------------------------------------------------------


        # ANN evaluation
        #---------------------------------------------------------------------------------------------------------------
        #transform data
        X_train_inner_ts = torch.Tensor(X_train_inner)
        X_test_inner_ts = torch.Tensor(X_test_inner)
        Y_train_inner_ts = torch.Tensor(Y_train_inner)
        Y_test_inner_ts = torch.Tensor(Y_test_inner)

        count=0
        loss_fn = torch.nn.MSELoss()
        for h in hidden_units:

            #define model with h hidden units
            model = lambda: torch.nn.Sequential(
                torch.nn.Linear(X_train_inner_ts.shape[1], h),
                torch.nn.Tanh(),
                torch.nn.Linear(h, 1),)

            net, final_loss, learning_curve = train_neural_net(model, loss_fn, X=X_train_inner_ts, y=Y_train_inner_ts, n_replicates=1, max_iter=10000)

            y_test_est = net(X_test_inner_ts)
            se = (y_test_est.float() - Y_test_inner_ts.float()) ** 2
            test_error_inner_ann[count,i2] = (sum(se).type(torch.float) / len(Y_test_inner_ts)).data.numpy()
            count += 1
        #---------------------------------------------------------------------------------------------------------------


    gen_error_inner_rg = np.mean(test_error_inner_rg, axis=1).T
    gen_error_inner_ann = np.mean(test_error_inner_ann, axis=1).T

    # Baseline model
    #-------------------------------------------------------------------------------------------------------------------
    # train model on all of train data
    y_hat_bl_opt = np.mean(Y_train)
    y_diff_bl = Y_test - y_hat_bl_opt
    test_error_outer_bl[i1] = np.matmul(y_diff_bl.transpose(), y_diff_bl) / Y_test.shape[0]
    results_table['E_test_bl'][i1] = np.round(float(np.matmul(y_diff_bl.transpose(), y_diff_bl) / Y_test.shape[0]), 3)
    #-------------------------------------------------------------------------------------------------------------------


    # Regression model
    #-------------------------------------------------------------------------------------------------------------------
    # find optimal regression model
    lambda_opt = lambdas[np.where(gen_error_inner_rg == gen_error_inner_rg.min())]
    results_table['lambda*'][i1] = np.round(lambda_opt[0], 3)

    # Train it on all train data
    w_opt = np.matmul(np.linalg.inv(np.matmul(X_train.transpose(), X_train) + lambda_opt[0] * np.identity(X_train.shape[1])),
                  (np.matmul(X_train.transpose(), Y_train)))

    # compute test error
    y_hat = np.matmul(X_test, w_opt)
    y_diff = Y_test - y_hat
    test_error_outer_rg[i1] = np.matmul(y_diff.transpose(), y_diff) / Y_test.shape[0]
    results_table['E_test_lr'][i1] = np.round((np.matmul(y_diff.transpose(), y_diff) / Y_test.shape[0]).squeeze(), 3)
    #-------------------------------------------------------------------------------------------------------------------


    # ANN model
    #-------------------------------------------------------------------------------------------------------------------
    h_opt = hidden_units[np.where(gen_error_inner_ann == gen_error_inner_ann.min())]
    results_table['h*'][i1] = h_opt[0]

    #transform data
    X_train_ts = torch.Tensor(X_train)
    Y_train_ts = torch.Tensor(Y_train)
    X_test_ts = torch.Tensor(X_test)
    Y_test_ts = torch.Tensor(Y_test)

    #define model with optimal number of hidden units
    model = lambda: torch.nn.Sequential(
        torch.nn.Linear(X_train_ts.shape[1], h_opt[0]),
        torch.nn.Tanh(),
        torch.nn.Linear(h_opt[0], 1), )

    #train it on new test data
    net, final_loss, learning_curve = train_neural_net(model, loss_fn, X=X_train_ts, y=Y_train_ts, n_replicates=1, max_iter=10000)

    #make prediction on test set
    y_test_est_outer = net(X_test_ts)
    se_outer = (y_test_est_outer.float() - Y_test_ts.float()) ** 2
    test_error_outer_ann[i1] = (sum(se_outer).type(torch.float) / len(Y_test_ts)).data.numpy()
    results_table['E_test_ann'][i1] = np.round((sum(se_outer).type(torch.float) / len(Y_test_ts)).data.numpy()[0], 3)
    #-------------------------------------------------------------------------------------------------------------------


    #statistical tests comparing
    #-------------------------------------------------------------------------------------------------------------------
    #transform tensor data
    se_outer_np = se_outer.detach().numpy()

    # 1. comparing lr and ann
    r_j_1[i1] = (1/len(y_diff))*np.sum(se_outer_np - y_diff**2)
    # 2. comparing lr and baseline
    r_j_2[i1] = (1/len(y_diff))*np.sum(y_diff - y_diff_bl**2)
    # 3. comparing ann and baseline
    r_j_3[i1] = (1/len(y_diff))*np.sum(se_outer_np - y_diff_bl**2)
    #-------------------------------------------------------------------------------------------------------------------


#p value approx
#-------------------------------------------------------------------------------------------------------------------
#t distribution
dof = k1 - 1
t_dist = scipy.stats.t(dof)

# rho can be assumed = 0 as our test sets don't overlap
rho = 0
alpha = 0.05

# lr and ann
r_mean_1 = np.mean(r_j_1)
sigma_1 = (1/(k1-1))*np.sum((r_j_1 - r_mean_1)**2)
t_hat_1 = r_mean_1/(np.sqrt(sigma_1)*np.sqrt(1/k1 + rho/(1-rho)))
p_val_1 = 2*t_dist.cdf(-abs(t_hat_1))
print('p_val_1:', p_val_1)

# 1-alpha confidence interval
lb_1 = scipy.stats.t.ppf(alpha/2, df=dof, loc=r_mean_1, scale=np.sqrt(sigma_1*(1/k1 + 1/(k1-1))))
print('lower bound 1: ', lb_1)
ub_1 = scipy.stats.t.ppf(1 - (alpha/2), df=dof, loc=r_mean_1, scale=np.sqrt(sigma_1*(1/k1 + 1/(k1-1))))
print('upper bound 1: ', ub_1)


# lr and baseline
r_mean_2 = np.mean(r_j_2)
sigma_2 = (1/(k1-1))*np.sum((r_j_2 - r_mean_2)**2)
t_hat_2 = r_mean_2/(np.sqrt(sigma_2)*np.sqrt(1/k1 + rho/(1-rho)))
p_val_2 = 2*t_dist.cdf(-abs(t_hat_2))
print('p_val_2:', p_val_2)

# 1-alpha confidence interval
lb_2 = scipy.stats.t.ppf(alpha/2, df=dof, loc=r_mean_2, scale=np.sqrt(sigma_2*(1/k1 + 1/(k1-1))))
print('lower bound 2: ', lb_2)
ub_2 = scipy.stats.t.ppf(1 - (alpha/2), df=dof, loc=r_mean_2, scale=np.sqrt(sigma_2*(1/k1 + 1/(k1-1))))
print('upper bound 2: ', ub_2)


# ann and baseline
r_mean_3 = np.mean(r_j_3)
sigma_3 = (1/(k1-1))*np.sum((r_j_3 - r_mean_3)**2)
t_hat_3 = r_mean_3/(np.sqrt(sigma_3)*np.sqrt(1/k1 + rho/(1-rho)))
p_val_3 = 2*t_dist.cdf(-abs(t_hat_3))
print('p_val_3:', p_val_3)

# 1-alpha confidence interval
lb_3 = scipy.stats.t.ppf(alpha/2, df=dof, loc=r_mean_3, scale=np.sqrt(sigma_3*(1/k1 + 1/(k1-1))))
print('lower bound 3: ', lb_3)
ub_3 = scipy.stats.t.ppf(1 - (alpha/2), df=dof, loc=r_mean_3, scale=np.sqrt(sigma_3*(1/k1 + 1/(k1-1))))
print('upper bound 3: ', ub_3)

#-------------------------------------------------------------------------------------------------------------------

print(results_table)
print('Finished Regression part b')


